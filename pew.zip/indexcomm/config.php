<?php

$server  = "sql207.epizy.com";
$db_user = "epiz_26691933";
$db_pass = "ugIBDtlWlQk60";
$db_name = "epiz_26691933_mydatabase";

$db = new PDO('mysql:host=localhost;dbname='. $db_name . ';charset=utf8', $db_user, $db_pass);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);